15PTS v1.2 - production award-selection regression tests

Add tests/bob-bow-integration.test.cjs to your repository's tests folder.
DO NOT replace existing tests or change package.json.
GitHub Actions will run npm test automatically.

Expected with supplied current app.js:
Expected new-file results: 4 pass, 4 fail (the missing-opposite-sex BOB and Group cases for each sex).
These failing tests document a genuine unguarded automatic BOW assignment in toggleAward().

Important limitation: the production app stores only aggregate class counts, not explicit WD/WB award presence. Zero opposite-sex class count is sufficient to rule out BOW, but nonzero counts alone cannot prove an opposite-sex Winners award was made. Thus the passing both-present tests exercise selection behavior only, not full eligibility validation. Saved record recalculation is outside this file's scope.
